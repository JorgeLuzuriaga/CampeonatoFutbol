public class EstadisticaJugador {
    private int contarFalta;
    private int contarGol;
    private int contarSanciones;

    // Getter para contarFalta
    public int getContarFalta() {
        return contarFalta;
    }

    // Setter para contarFalta
    public void setContarFalta(int contarFalta) {
        this.contarFalta = contarFalta;
    }

    // Getter para contarGol
    public int getContarGol() {
        return contarGol;
    }

    // Setter para contarGol
    public void setContarGol(int contarGol) {
        this.contarGol = contarGol;
    }

    // Getter para contarSanciones
    public int getContarSanciones() {
        return contarSanciones;
    }

    // Setter para contarSanciones
    public void setContarSanciones(int contarSanciones) {
        this.contarSanciones = contarSanciones;
    }
}
