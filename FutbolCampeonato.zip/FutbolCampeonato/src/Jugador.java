public class Jugador extends Persona {
    // Puede tener más atributos y métodos específicos de Jugador
}